// p1311b.c
#include <stdio.h>
int a = 1, b;
int main(void)
{
   b = a;
   printf("%d\n", b);
   return 0;
}
