// p1311a.c
#include <stdio.h>
int a = 1, b;
int main(void)
{
   b = - - - - - - - - + - - (- -a);
   printf("%d\n", b);
   return 0;
}
