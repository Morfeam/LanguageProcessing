// p0104.c
#include <stdio.h>
int main(void)
{
   int a = 5, b = 0;
   a = a/b;
   printf("%d\n", a);
   return 0;
}
