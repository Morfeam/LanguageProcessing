// keyin.c
#include <stdio.h>
int x;
int main(void)
{
   scanf("%d", &x);        // read from keyboard
   printf("x = %d\n", x);  // display value
   return 0;
}
