# p0104.py
a = 5
b = 0
a = a/b
print(a)
