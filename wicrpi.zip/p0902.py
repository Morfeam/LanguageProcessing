a = 1 + 2 + 3
b = a + 4
c = a + b
